$(document).ready(function() {

$('.global-wrapper').attr("id", "global-move-move");
$('.site-footer').attr("id", "footer-move-move");
$('.main-navigation').attr("id", "main-navigation-display");
 
});
