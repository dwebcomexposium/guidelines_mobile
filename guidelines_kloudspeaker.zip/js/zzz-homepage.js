$(document).ready(function() {

var page = window.location.pathname;
     if(page == '/'){
       $('#zone1').css({

    'height': '100vh',
    'background-image': 'url(/theme/guidelines_mobile/img/bc-header.jpg)',
    'background-repeat': 'no-repeat',
    'background-size': 'cover',
'margin-top': '-100px',
'background-position': '50% 50%'
});
}
var page = window.location.pathname;
     if(page == '/'){
       $('#zone2').css({

    'height': '100%',
    'background' : '#ffffff',
    'margin-bottom' : '25px',
    'padding' : '0.7em'
});
} 
});
